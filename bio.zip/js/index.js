function showPanel(id) {

	$("#"+id).click(function(){
		$(".left-column .active").removeClass("active");
		$("#"+id).addClass("active");
		$(".center-column .active").removeClass("active");
		$("."+id).addClass("active");
	})
}

showPanel("a");
showPanel("b");
showPanel("c");
showPanel("d");
showPanel("e");
showPanel("f");
showPanel("g");